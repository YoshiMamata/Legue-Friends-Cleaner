@echo off
setlocal
cd /d "%~dp0"
title League Friends Manager V2
if not exist "%~dp0LeagueFriendsManager.exe" (
    echo ERROR: LeagueFriendsManager.exe was not found in this folder.
    echo Extract the complete ZIP before running Launch.cmd.
    pause
    exit /b 1
)
"%~dp0LeagueFriendsManager.exe"
if errorlevel 1 (
    echo.
    echo The program exited with an error. Read the message above.
    pause
)
endlocal
