@echo off
setlocal
cd /d "%~dp0"
title League Friends Manager V2 - DEMO
if not exist "%~dp0LeagueFriendsManager.exe" (
    echo ERROR: LeagueFriendsManager.exe was not found in this folder.
    pause
    exit /b 1
)
"%~dp0LeagueFriendsManager.exe" --demo
if errorlevel 1 pause
endlocal
