# League Friends Manager V2 — Final

**Cleaned by YoshiMamata#MUE**

O aplicație independentă pentru Windows, pentru organizarea listei de prieteni League of Legends. Rulează din CMD și deschide automat o interfață modernă în browser. **Nu necesită Python, Go, instalare sau cont/API key suplimentar.**

## 1. Pornire rapidă

1. Dezarhivează întregul ZIP într-un folder obișnuit, de exemplu Desktop.
2. Pornește **League of Legends**, autentifică-te și lasă clientul deschis.
3. Dublu-click pe `Launch.cmd` sau pe `LeagueFriendsManager.exe`. Poți și din CMD: `LeagueFriendsManager.exe`.
4. Se va deschide fereastra CMD și apoi browserul implicit, cu pagina aplicației.
5. **Primul pas obligatoriu** este să localizezi lockfile-ul League Client:
   - Apasă **Auto-detect** pentru detectare automată;
   - Sau **Browse**, pentru a-l alege din Windows;
   - Sau introdu manual calea, de exemplu `C:\Riot Games\League of Legends\lockfile`.
6. Apasă **Connect & load friends**. După validare se deschide interfața cu lista.
7. Schimbă limba cu butonul **RO / EN**, din dreapta sus. Alegerea se păstrează.

**Important:** Fereastra CMD trebuie să rămână deschisă cât timp folosești aplicația. Butonul „Exit app” oprește serverul local. Programul rulează numai pe Windows 64-bit (10/11) și are nevoie de un browser modern (Edge/Chrome/Firefox).

## 2. Funcționalități

- Citire automată a prietenilor din **League Client** prin API-ul local (LCU).
- Căutare după **Riot ID / nume, notă, grup**.
- Filtre **status**: Toți / Online / Offline / Necunoscut.
- Filtre **activitate**: Oricare / Inactiv cel puțin 7, 30, 90, 180 de zile / Dată necunoscută.
- Filtre după **grup**.
- Sortare **A–Z, Z–A, recent–vechi, vechi–recent, grup A–Z**.
- Bifare individuală, „Selectează filtrații” și „Deselectează”. Selecția se păstrează când schimbi filtrul; verifică numărul de selectați înainte de ștergere.
- **Protejează / Elimină protecția** pentru prietenii selectați. Prietenii protejați au steluță, sunt salvați în setările locale și nu pot fi șterși în bulk.
- **Export CSV** pentru lista filtrată (salvat local + descărcat în browser).
- **Bulk delete** cu confirmare obligatorie, backup CSV complet, reverificare lockfile/cont/identitate și pauză între cererile de ștergere.
- **Oprește restul** în timpul unei ștergeri: întrerupe cererile încă neexecutate; nu reface ștergerile deja realizate.
- **Reconectare** prin „Schimbă lockfile” dacă League a fost repornit.
- La sfârșitul unei curățări cu ștergeri reușite apare semnătura **Cleaned by YoshiMamata#MUE**.

## 3. Cum funcționează activitatea

Lista de prieteni vine din League Client. Dacă Riot Client local permite citirea endpointului `/chat/v4/friends`, aplicația încearcă să preia **ultima conectare la Riot**, în funcție de datele returnate pentru fiecare PUUID.

**Aceasta NU este data ultimului meci de League of Legends.** Absența unei date înseamnă **„Necunoscut”**, nu „inactiv”. Prietenii conectați acum au activitate 0 zile. Filtrele „Inactiv ≥ N zile” **nu includ** datele necunoscute.

Clientul Riot poate să nu furnizeze acest câmp sau API-ul să se modifice. În acest caz, filtrele alfabetice, status, grup și ștergerea continuă să funcționeze, însă datele de activitate lipsă rămân necunoscute.

## 4. Siguranță și backup

La ștergere:

1. Selectezi prietenii. Dacă ai selectat și prieteni protejați, ei sunt excluși automat.
2. Citești lista de confirmare și tastezi exact `STERGE N` în română sau `DELETE N` în engleză, unde **N** este numărul de prieteni eligibili.
3. Înainte de prima ștergere, aplicația verifică din nou lockfile-ul, contul (dacă poate fi identificat) și lista actuală de prieteni și salvează un backup **al întregii liste**, nu doar al celor selectați.
4. Șterge fiecare prieten verificat individual, cu o pauză scurtă și posibilitatea de a opri restul.

**Fișierele de backup nu reprezintă un buton Undo.** Ele salvează identificatorii și informațiile necesare pentru a regăsi prietenii, dar nu îi readaugă automat. Verifică foarte atent selecția!

Datele locale sunt în:

- Backupuri: `%LOCALAPPDATA%\LeagueFriendsManager\backups`
- Setări RO/EN și prieteni protejați: `%LOCALAPPDATA%\LeagueFriendsManager\settings.json`

**Parola din lockfile este păstrată numai în memoria procesului** și este folosită exclusiv pentru HTTPS către `127.0.0.1`. Nu este scrisă în backupuri, setări sau loguri. Interfața web este accesibilă doar prin `127.0.0.1` și folosește un token aleator de sesiune pentru API-ul local. Nu trimite altcuiva conținutul lockfile-ului.

## 5. Mod demo

Rulează `Launch_Demo.cmd`. Se deschide interfața cu prieteni **fictivi**. Poți încerca filtrele, protecția și traducerile fără a porni League. **Ștergerea este dezactivată complet în demo.**

## 6. Depanare

**Clientul nu se conectează:** verifică dacă League este pornit și dacă ai selectat **lockfile-ul din folderul League of Legends**, nu pe cel al Riot Client. Apasă Browse și indică fișierul exact.

**Nu găsește automat lockfile-ul:** folosește Browse sau calea completă. Jocul poate fi instalat într-un folder nestandard.

**Datele de activitate sunt necunoscute:** este normal când endpointul Riot Client local nu este disponibil sau nu oferă timestamp. Nu înseamnă că toți sunt inactivi.

**După restart League apare eroare:** apasă „Schimbă lockfile”, alege fișierul nou și reconectează-te.

**Browserul nu se deschide:** copiază URL-ul afișat în CMD, de forma `http://127.0.0.1:xxxxx`, în browser.

**Windows avertizează despre EXE:** programul este compilat local pentru Windows, dar executabilul nu este semnat digital. Codul-sursă este inclus în directorul `source` pentru auditare/recompilare. Nu dezactiva protecțiile Windows în general.

## 7. Cod sursă și teste

În `source/` găsești codul Go 1.23, interfața HTML/CSS/JavaScript și testele. Pentru recompilare (opțional, doar dacă ești developer):

```cmd
cd source
go test ./...
go build -o ..\LeagueFriendsManager.exe .
```

Pentru utilizarea normală nu ai nevoie de Go sau de Python.

## 8. Note și responsabilitate

Versiunea a fost compilată ca executabil Windows x64 și testată automat pe un client HTTPS local simulat, inclusiv scenarii de backup și ștergere. **Nu a fost testată pe un cont League real în acest mediu** și nu poate garanta compatibilitate pe toate versiunile viitoare de client.

League Client API (LCU) nu este un serviciu susținut oficial pentru aplicații terțe; Riot nu garantează documentație completă sau stabilitatea endpointurilor. Dacă distribui public programul, consultă politicile Riot Developer și cerințele de înregistrare a aplicației.

> League Friends Manager isn't endorsed by Riot Games and doesn't reflect the views or opinions of Riot Games or anyone officially involved in producing or managing Riot Games properties. Riot Games, and all associated properties are trademarks or registered trademarks of Riot Games, Inc.
