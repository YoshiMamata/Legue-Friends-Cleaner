package main

import (
	"encoding/json"
	"io"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"testing"
	"time"
)

func TestLockfileRequiresLeagueHTTPS(t *testing.T) {
	path := filepath.Join(t.TempDir(), "lockfile")
	if err := os.WriteFile(path, []byte("LeagueClient:777:12345:safe-token:https"), 0600); err != nil {
		t.Fatal(err)
	}
	got, err := readLockfile(path, "league")
	if err != nil || got.Port != 12345 || got.Password != "safe-token" {
		t.Fatalf("unexpected lockfile: %+v %v", got, err)
	}
	if err := os.WriteFile(path, []byte("Fake:777:12345:safe-token:http"), 0600); err != nil {
		t.Fatal(err)
	}
	if _, err := readLockfile(path, "league"); err == nil {
		t.Fatal("invalid lockfile accepted")
	}
}

func TestActivityKeepsUnknownUnknown(t *testing.T) {
	now := time.Unix(1762900000, 0)
	raw := []map[string]any{{"id": json.Number("90071992547409933"), "puuid": "p1", "gameName": "Alice", "gameTag": "EUW", "availability": "offline", "groupName": "Duo"},
		{"id": "2", "puuid": "p2", "name": "Bob", "availability": "chat"}}
	result := normalizeFriends(raw, nil, now)
	if result[0].ID != "90071992547409933" || result[0].DaysInactive != nil || result[0].LastOnlineMs != nil {
		t.Fatalf("unknown activity or ID incorrectly normalized: %+v", result[0])
	}
	if result[1].DaysInactive == nil || *result[1].DaysInactive != 0 {
		t.Fatal("online users should be active now")
	}
	old := now.Add(-110 * 24 * time.Hour).UnixMilli()
	riot := map[string]map[string]any{"p1": {"last_online_ts": strconv.FormatInt(old, 10)}}
	result = normalizeFriends(raw, riot, now)
	if result[0].DaysInactive == nil || *result[0].DaysInactive != 110 {
		t.Fatalf("expected 110 days, got %+v", result[0])
	}
}

func TestCSVInjectionEscaping(t *testing.T) {
	for _, value := range []string{"=1+1", "+cmd", "-hack", "@SUM(A1)", "\tboom", "\nboom"} {
		if !strings.HasPrefix(csvSafe(value), "'") {
			t.Fatalf("unsafe CSV cell: %q", value)
		}
	}
	if csvSafe("Alice#EUW") != "Alice#EUW" {
		t.Fatal("ordinary name unexpectedly modified")
	}
}

func TestDemoDeletionRejectedAndAuth(t *testing.T) {
	t.Setenv("LOCALAPPDATA", t.TempDir())
	s, err := newAppServer("test-secret", true)
	if err != nil {
		t.Fatal(err)
	}
	noToken := httptest.NewRequest("GET", "/api/friends", nil)
	recorder := httptest.NewRecorder()
	s.serveAPI(recorder, noToken)
	if recorder.Code != 403 {
		t.Fatalf("expected 403 without token; got %d", recorder.Code)
	}
	request := httptest.NewRequest("POST", "/api/delete", strings.NewReader(`{"keys":["p:demo-puuid-0"],"confirmation":"DELETE 1","language":"en"}`))
	request.Header.Set("X-LFM-Session", "test-secret")
	recorder = httptest.NewRecorder()
	s.serveAPI(recorder, request)
	if recorder.Code != 403 {
		t.Fatalf("demo deletion should be forbidden, got %d", recorder.Code)
	}
}

func TestBulkDeleteProtectedAndBackup(t *testing.T) {
	t.Setenv("LOCALAPPDATA", t.TempDir())
	var mu sync.Mutex
	removed := []string{}
	friends := []map[string]any{{"id": "22", "puuid": "puuid-one", "gameName": "First", "gameTag": "ONE", "availability": "offline"},
		{"id": "23", "puuid": "puuid-two", "gameName": "Keep", "gameTag": "TWO", "availability": "offline"}}
	mock := httptest.NewTLSServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/lol-chat/v1/me":
			_ = json.NewEncoder(w).Encode(map[string]string{"puuid": "account-A"})
		case "/lol-chat/v1/friends":
			mu.Lock()
			copyFriends := append([]map[string]any{}, friends...)
			mu.Unlock()
			_ = json.NewEncoder(w).Encode(copyFriends)
		case "/lol-chat/v1/friends/22":
			if r.Method != "DELETE" {
				t.Errorf("unexpected method %s", r.Method)
			}
			mu.Lock()
			removed = append(removed, "22")
			friends = friends[1:]
			mu.Unlock()
			w.WriteHeader(204)
		case "/lol-chat/v1/friends/23":
			t.Error("protected friend was deleted")
			w.WriteHeader(403)
		default:
			t.Errorf("unexpected path %s", r.URL.Path)
			w.WriteHeader(404)
		}
	}))
	defer mock.Close()
	endpoint := strings.TrimPrefix(mock.URL, "https://127.0.0.1:")
	if endpoint == mock.URL {
		t.Fatalf("unexpected mock URL %s", mock.URL)
	}
	lockfile := filepath.Join(t.TempDir(), "lockfile")
	if err := os.WriteFile(lockfile, []byte("LeagueClient:12:"+endpoint+":localpass:https"), 0600); err != nil {
		t.Fatal(err)
	}
	s, err := newAppServer("secret", false)
	if err != nil {
		t.Fatal(err)
	}
	do := func(path, payload string) *httptest.ResponseRecorder {
		method := "GET"
		var body io.Reader
		if payload != "" {
			method = "POST"
			body = strings.NewReader(payload)
		}
		r := httptest.NewRequest(method, path, body)
		r.Header.Set("X-LFM-Session", "secret")
		w := httptest.NewRecorder()
		s.serveAPI(w, r)
		return w
	}
	response := do("/api/connect", `{"path":`+strconv.Quote(lockfile)+`}`)
	if response.Code != 200 {
		t.Fatalf("connect failed: %s", response.Body.String())
	}
	protection := do("/api/protect", `{"keys":["p:puuid-two"],"protect":true}`)
	if protection.Code != 200 {
		t.Fatalf("protect failed: %s", protection.Body.String())
	}
	bad := do("/api/delete", `{"keys":["p:puuid-one","p:puuid-two"],"confirmation":"DELETE 2","language":"en"}`)
	if bad.Code != 400 {
		t.Fatalf("wrong confirmation should fail, got %d", bad.Code)
	}
	start := do("/api/delete", `{"keys":["p:puuid-one","p:puuid-two"],"confirmation":"DELETE 1","language":"en"}`)
	if start.Code != 202 {
		t.Fatalf("delete did not start: %d %s", start.Code, start.Body.String())
	}
	deadline := time.Now().Add(5 * time.Second)
	var result jobView
	for time.Now().Before(deadline) {
		status := do("/api/job", "")
		if err := json.Unmarshal(status.Body.Bytes(), &result); err != nil {
			t.Fatal(err)
		}
		if result.State == "finished" {
			break
		}
		time.Sleep(20 * time.Millisecond)
	}
	if result.State != "finished" || result.Deleted != 1 || result.Signature != signature || result.Backup == "" {
		t.Fatalf("unexpected job result: %+v", result)
	}
	mu.Lock()
	nRemoved := len(removed)
	mu.Unlock()
	if nRemoved != 1 {
		t.Fatalf("expected 1 removal, got %d", nRemoved)
	}
	backup, err := os.ReadFile(filepath.Join(s.backups, result.Backup))
	if err != nil {
		t.Fatal(err)
	}
	if !strings.Contains(string(backup), "First#ONE") || !strings.Contains(string(backup), "Keep#TWO") {
		t.Fatalf("backup did not include the whole list: %s", backup)
	}
	status := do("/api/friends", "")
	if !strings.Contains(status.Body.String(), "Keep#TWO") || strings.Contains(status.Body.String(), "First#ONE") {
		t.Fatalf("friend list was not refreshed after deletion: %s", status.Body.String())
	}
}
