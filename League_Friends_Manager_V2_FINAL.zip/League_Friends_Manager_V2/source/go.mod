module leaguefriendsmanager

go 1.23
