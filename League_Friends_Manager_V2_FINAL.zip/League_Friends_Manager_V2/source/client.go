package main

import (
	"crypto/tls"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"net/url"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"time"
)

type lockfileInfo struct {
	Path     string
	Port     int
	Password string
}

type localClient struct {
	info lockfileInfo
	http *http.Client
	auth string
}

func readLockfile(path, kind string) (lockfileInfo, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return lockfileInfo{}, fmt.Errorf("cannot read lockfile: %w", err)
	}
	chunks := strings.SplitN(strings.TrimSpace(strings.TrimPrefix(string(raw), "\ufeff")), ":", 5)
	if len(chunks) != 5 {
		return lockfileInfo{}, errors.New("invalid lockfile format")
	}
	name, portText, password, protocol := strings.ToLower(chunks[0]), chunks[2], chunks[3], chunks[4]
	if kind == "league" && !strings.Contains(name, "leagueclient") {
		return lockfileInfo{}, errors.New("this is not a League Client lockfile")
	}
	if kind == "riot" && !strings.Contains(name, "riotclient") && !strings.Contains(name, "riot client") {
		return lockfileInfo{}, errors.New("this is not a Riot Client lockfile")
	}
	if strings.ToLower(protocol) != "https" || password == "" {
		return lockfileInfo{}, errors.New("invalid local HTTPS lockfile")
	}
	port, err := strconv.Atoi(portText)
	if err != nil || port < 1 || port > 65535 {
		return lockfileInfo{}, errors.New("invalid lockfile port")
	}
	absolute, err := filepath.Abs(path)
	if err != nil {
		return lockfileInfo{}, err
	}
	return lockfileInfo{Path: absolute, Port: port, Password: password}, nil
}

func newLocalClient(path, kind string) (*localClient, error) {
	lock, err := readLockfile(path, kind)
	if err != nil {
		return nil, err
	}
	// Only 127.0.0.1 is contacted; Riot uses a local self-signed certificate.
	// Never reuse this HTTP transport for public internet requests.
	transport := &http.Transport{Proxy: nil, TLSClientConfig: &tls.Config{InsecureSkipVerify: true}, DisableKeepAlives: true}
	return &localClient{
		info: lock,
		http: &http.Client{Transport: transport, Timeout: 8 * time.Second},
		auth: "Basic " + base64.StdEncoding.EncodeToString([]byte("riot:"+lock.Password)),
	}, nil
}

func (c *localClient) sameSession() bool {
	updated, err := readLockfile(c.info.Path, "league")
	if err != nil {
		return false
	}
	return updated.Port == c.info.Port && updated.Password == c.info.Password
}

func (c *localClient) request(method, route string, dest any) error {
	if (method != http.MethodGet && method != http.MethodDelete) || !strings.HasPrefix(route, "/") || strings.HasPrefix(route, "//") {
		return errors.New("unsupported local request")
	}
	uri := fmt.Sprintf("https://127.0.0.1:%d%s", c.info.Port, route)
	req, err := http.NewRequest(method, uri, nil)
	if err != nil {
		return err
	}
	req.Header.Set("Authorization", c.auth)
	req.Header.Set("Accept", "application/json")
	resp, err := c.http.Do(req)
	if err != nil {
		return fmt.Errorf("local client unavailable: %w", err)
	}
	defer resp.Body.Close()
	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return fmt.Errorf("League/Riot client returned HTTP %d", resp.StatusCode)
	}
	if dest == nil || resp.StatusCode == http.StatusNoContent {
		return nil
	}
	dec := json.NewDecoder(resp.Body)
	dec.UseNumber() // preserve large League integer identifiers exactly
	if err := dec.Decode(dest); err != nil {
		return fmt.Errorf("invalid local client response: %w", err)
	}
	return nil
}

func (c *localClient) getFriends() ([]map[string]any, error) {
	var list []map[string]any
	if err := c.request(http.MethodGet, "/lol-chat/v1/friends", &list); err != nil {
		return nil, err
	}
	if list == nil {
		return nil, errors.New("unexpected friends list response")
	}
	return list, nil
}

func (c *localClient) accountIdentity() string {
	var me map[string]any
	if err := c.request(http.MethodGet, "/lol-chat/v1/me", &me); err != nil {
		return ""
	}
	for _, field := range []string{"puuid", "summonerId", "id"} {
		value := strField(me[field])
		if value != "" {
			return field + ":" + value
		}
	}
	return ""
}

func (c *localClient) removeFriend(friendID string) error {
	if friendID == "" {
		return errors.New("missing League friend ID")
	}
	return c.request(http.MethodDelete, "/lol-chat/v1/friends/"+url.PathEscape(friendID), nil)
}

func strField(v any) string {
	if v == nil {
		return ""
	}
	switch value := v.(type) {
	case string:
		return strings.TrimSpace(value)
	case json.Number:
		return value.String()
	case float64:
		return strconv.FormatFloat(value, 'f', -1, 64)
	default:
		return ""
	}
}

func riotClientLockfile() string {
	local := os.Getenv("LOCALAPPDATA")
	if local == "" {
		return ""
	}
	return filepath.Join(local, "Riot Games", "Riot Client", "Config", "lockfile")
}

func getRiotFriends() (map[string]map[string]any, bool) {
	path := riotClientLockfile()
	if path == "" {
		return map[string]map[string]any{}, false
	}
	c, err := newLocalClient(path, "riot")
	if err != nil {
		return map[string]map[string]any{}, false
	}
	var data struct {
		Friends []map[string]any `json:"friends"`
	}
	if err := c.request(http.MethodGet, "/chat/v4/friends", &data); err != nil || data.Friends == nil {
		return map[string]map[string]any{}, false
	}
	byPUUID := make(map[string]map[string]any, len(data.Friends))
	for _, f := range data.Friends {
		puuid := strings.ToLower(strField(f["puuid"]))
		if puuid != "" {
			byPUUID[puuid] = f
		}
	}
	return byPUUID, true
}
