package main

import (
	"crypto/rand"
	"embed"
	"encoding/base64"
	"flag"
	"fmt"
	"io/fs"
	"log"
	"net"
	"net/http"
	"os/exec"
	"runtime"
	"strings"
	"time"
)

//go:embed assets/*
var assets embed.FS

func main() {
	demo := flag.Bool("demo", false, "Start with fictional friends, without a League connection")
	noBrowser := flag.Bool("no-browser", false, "Do not automatically open the browser")
	flag.Parse()

	raw := make([]byte, 32)
	if _, err := rand.Read(raw); err != nil {
		log.Fatal(err)
	}
	token := base64.RawURLEncoding.EncodeToString(raw)

	server, err := newAppServer(token, *demo)
	if err != nil {
		log.Fatal(err)
	}
	listener, err := net.Listen("tcp4", "127.0.0.1:0")
	if err != nil {
		log.Fatal(err)
	}
	address := "http://" + listener.Addr().String()
	server.origin = address
	sub, err := fs.Sub(assets, "assets")
	if err != nil {
		log.Fatal(err)
	}

	mux := http.NewServeMux()
	mux.Handle("/assets/", http.StripPrefix("/assets/", http.FileServer(http.FS(sub))))
	mux.HandleFunc("/", server.serveIndex)
	mux.HandleFunc("/api/", server.serveAPI)
	httpServer := &http.Server{
		Handler:           securityHeaders(mux),
		ReadHeaderTimeout: 5 * time.Second,
		IdleTimeout:       45 * time.Second,
	}
	server.shutdown = func() { _ = httpServer.Close() }

	fmt.Println()
	fmt.Println("  League Friends Manager V2")
	fmt.Println("  -------------------------")
	fmt.Println("  Local address:", address)
	if *demo {
		fmt.Println("  DEMO MODE - no real friend data is loaded or modified")
	}
	fmt.Println("  Keep this CMD window open while using the app.")
	fmt.Println("  Close it or press Ctrl+C to stop the app.")
	fmt.Println()

	go func() {
		time.Sleep(250 * time.Millisecond)
		if !*noBrowser {
			if err := openBrowser(address); err != nil {
				fmt.Println("  Browser did not open automatically. Copy the address above.")
			}
		}
	}()
	if err := httpServer.Serve(listener); err != nil && err != http.ErrServerClosed {
		log.Fatal(err)
	}
}

func openBrowser(url string) error {
	switch runtime.GOOS {
	case "windows":
		return exec.Command("rundll32.exe", "url.dll,FileProtocolHandler", url).Start()
	case "darwin":
		return exec.Command("open", url).Start()
	default:
		return exec.Command("xdg-open", url).Start()
	}
}

func securityHeaders(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("X-Content-Type-Options", "nosniff")
		w.Header().Set("Referrer-Policy", "no-referrer")
		w.Header().Set("X-Frame-Options", "DENY")
		w.Header().Set("Cache-Control", "no-store")
		w.Header().Set("Content-Security-Policy", strings.Join([]string{
			"default-src 'none'", "script-src 'self'", "style-src 'self'",
			"img-src 'self' data:", "connect-src 'self'", "font-src 'self'",
			"base-uri 'none'", "form-action 'none'", "frame-ancestors 'none'",
		}, "; "))
		next.ServeHTTP(w, r)
	})
}
