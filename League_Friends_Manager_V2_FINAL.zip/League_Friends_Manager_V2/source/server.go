package main

import (
	"crypto/subtle"
	"encoding/csv"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"
)

const signature = "Cleaned by YoshiMamata#MUE"

type appSettings struct {
	Language  string   `json:"language"`
	Protected []string `json:"protected"`
}

type jobView struct {
	State     string   `json:"state"`
	Total     int      `json:"total"`
	Processed int      `json:"processed"`
	Deleted   int      `json:"deleted"`
	Skipped   []string `json:"skipped"`
	Failed    []string `json:"failed"`
	Backup    string   `json:"backup"`
	Current   string   `json:"current"`
	Signature string   `json:"signature"`
}

type deleteJob struct {
	jobView
	cancel chan struct{}
	once   sync.Once
}

type appServer struct {
	mu              sync.Mutex
	token           string
	origin          string
	storage         string
	backups         string
	language        string
	protected       map[string]bool
	client          *localClient
	account         string
	lockpath        string
	friends         []Friend
	hasRiotActivity bool
	demo            bool
	busy            bool
	job             *deleteJob
	shutdown        func()
}

func newAppServer(token string, demo bool) (*appServer, error) {
	local := os.Getenv("LOCALAPPDATA")
	if local == "" {
		dir, err := os.UserConfigDir()
		if err != nil {
			return nil, err
		}
		local = dir
	}
	directory := filepath.Join(local, "LeagueFriendsManager")
	backups := filepath.Join(directory, "backups")
	if err := os.MkdirAll(backups, 0700); err != nil {
		return nil, err
	}
	s := &appServer{token: token, storage: directory, backups: backups, language: "en", protected: map[string]bool{}, demo: demo}
	raw, err := os.ReadFile(filepath.Join(directory, "settings.json"))
	if err == nil {
		var data appSettings
		if json.Unmarshal(raw, &data) == nil {
			if data.Language == "ro" || data.Language == "en" {
				s.language = data.Language
			}
			for _, key := range data.Protected {
				if key != "" {
					s.protected[key] = true
				}
			}
		}
	}
	if demo {
		s.friends = demoFriends()
	}
	return s, nil
}

func (s *appServer) saveSettingsLocked() error {
	keys := make([]string, 0, len(s.protected))
	for key := range s.protected {
		keys = append(keys, key)
	}
	sort.Strings(keys)
	data, err := json.MarshalIndent(appSettings{Language: s.language, Protected: keys}, "", "  ")
	if err != nil {
		return err
	}
	tmp := filepath.Join(s.storage, "settings.json.tmp")
	if err := os.WriteFile(tmp, data, 0600); err != nil {
		return err
	}
	path := filepath.Join(s.storage, "settings.json")
	if err := os.Rename(tmp, path); err != nil {
		// Certain Windows versions refuse to rename over an existing file.
		if fallback := os.WriteFile(path, data, 0600); fallback != nil {
			return fallback
		}
		_ = os.Remove(tmp)
	}
	return nil
}

func (s *appServer) serveIndex(w http.ResponseWriter, r *http.Request) {
	if r.URL.Path != "/" || r.Method != "GET" {
		http.NotFound(w, r)
		return
	}
	raw, err := assets.ReadFile("assets/index.html")
	if err != nil {
		http.Error(w, "UI unavailable", 500)
		return
	}
	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	page := strings.ReplaceAll(string(raw), "__SESSION_TOKEN__", s.token)
	_, _ = io.WriteString(w, page)
}

func (s *appServer) serveAPI(w http.ResponseWriter, r *http.Request) {
	if subtle.ConstantTimeCompare([]byte(r.Header.Get("X-LFM-Session")), []byte(s.token)) != 1 {
		writeError(w, 403, "This request was not made by the local app window.")
		return
	}
	if origin := r.Header.Get("Origin"); origin != "" && origin != s.origin {
		writeError(w, 403, "Invalid browser origin.")
		return
	}
	if r.Method == http.MethodPost {
		r.Body = http.MaxBytesReader(w, r.Body, 1024*1024)
	}
	switch r.URL.Path {
	case "/api/status":
		if !method(w, r, http.MethodGet) {
			return
		}
		s.apiStatus(w)
	case "/api/locate":
		if !method(w, r, http.MethodGet) {
			return
		}
		path := detectLockfile()
		writeJSON(w, 200, map[string]any{"path": path, "found": path != ""})
	case "/api/pick":
		if !method(w, r, http.MethodPost) {
			return
		}
		path, err := pickLockfile()
		if err != nil {
			writeError(w, 400, err.Error())
			return
		}
		writeJSON(w, 200, map[string]any{"path": path})
	case "/api/connect":
		if !method(w, r, http.MethodPost) {
			return
		}
		s.apiConnect(w, r)
	case "/api/disconnect":
		if !method(w, r, http.MethodPost) {
			return
		}
		s.apiDisconnect(w)
	case "/api/friends":
		if !method(w, r, http.MethodGet) {
			return
		}
		s.apiFriends(w)
	case "/api/refresh":
		if !method(w, r, http.MethodPost) {
			return
		}
		s.apiRefresh(w)
	case "/api/language":
		if !method(w, r, http.MethodPost) {
			return
		}
		s.apiLanguage(w, r)
	case "/api/protect":
		if !method(w, r, http.MethodPost) {
			return
		}
		s.apiProtect(w, r)
	case "/api/export":
		if !method(w, r, http.MethodPost) {
			return
		}
		s.apiExport(w, r)
	case "/api/delete":
		if !method(w, r, http.MethodPost) {
			return
		}
		s.apiDelete(w, r)
	case "/api/job":
		if !method(w, r, http.MethodGet) {
			return
		}
		s.apiJob(w)
	case "/api/cancel":
		if !method(w, r, http.MethodPost) {
			return
		}
		s.apiCancel(w)
	case "/api/open-backups":
		if !method(w, r, http.MethodPost) {
			return
		}
		s.apiOpenBackups(w)
	case "/api/exit":
		if !method(w, r, http.MethodPost) {
			return
		}
		writeJSON(w, 200, map[string]bool{"ok": true})
		go func() {
			time.Sleep(300 * time.Millisecond)
			if s.shutdown != nil {
				s.shutdown()
			}
		}()
	default:
		if strings.HasPrefix(r.URL.Path, "/api/backups/") {
			if !method(w, r, http.MethodGet) {
				return
			}
			s.apiDownload(w, r)
			return
		}
		http.NotFound(w, r)
	}
}

func method(w http.ResponseWriter, r *http.Request, expected string) bool {
	if r.Method == expected {
		return true
	}
	w.Header().Set("Allow", expected)
	writeError(w, 405, "Method not allowed")
	return false
}
func writeJSON(w http.ResponseWriter, code int, data any) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.WriteHeader(code)
	_ = json.NewEncoder(w).Encode(data)
}
func writeError(w http.ResponseWriter, code int, msg string) {
	writeJSON(w, code, map[string]string{"error": msg})
}
func decodeBody(r *http.Request, target any) error {
	defer r.Body.Close()
	dec := json.NewDecoder(r.Body)
	if err := dec.Decode(target); err != nil {
		return fmt.Errorf("invalid request: %w", err)
	}
	return nil
}

func (s *appServer) apiStatus(w http.ResponseWriter) {
	s.mu.Lock()
	defer s.mu.Unlock()
	writeJSON(w, 200, map[string]any{
		"connected": s.client != nil || s.demo, "demo": s.demo,
		"lockfile": s.lockpath, "count": len(s.friends),
		"language": s.language, "riotActivityAvailable": s.hasRiotActivity,
		"busy": s.busy,
	})
}

func (s *appServer) apiConnect(w http.ResponseWriter, r *http.Request) {
	var body struct {
		Path string `json:"path"`
	}
	if err := decodeBody(r, &body); err != nil {
		writeError(w, 400, err.Error())
		return
	}
	if strings.TrimSpace(body.Path) == "" {
		writeError(w, 400, "Select the League lockfile first.")
		return
	}
	s.mu.Lock()
	if s.busy {
		s.mu.Unlock()
		writeError(w, 409, "Finish the ongoing operation first.")
		return
	}
	s.mu.Unlock()
	c, err := newLocalClient(body.Path, "league")
	if err != nil {
		writeError(w, 400, err.Error())
		return
	}
	rows, err := c.getFriends()
	if err != nil {
		writeError(w, 502, err.Error())
		return
	}
	account := c.accountIdentity()
	riot, available := getRiotFriends()
	friends := normalizeFriends(rows, riot, time.Now())
	s.mu.Lock()
	if s.busy {
		s.mu.Unlock()
		writeError(w, 409, "An operation started while connecting. Please retry.")
		return
	}
	s.client = c
	s.account = account
	s.lockpath = c.info.Path
	s.friends = friends
	s.hasRiotActivity = available
	s.demo = false
	s.job = nil
	s.mu.Unlock()
	writeJSON(w, 200, map[string]any{"ok": true, "count": len(friends), "riotActivityAvailable": available})
}

func (s *appServer) apiDisconnect(w http.ResponseWriter) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.busy {
		writeError(w, 409, "Deletion in progress.")
		return
	}
	s.client = nil
	s.account = ""
	s.lockpath = ""
	s.friends = nil
	s.hasRiotActivity = false
	s.demo = false
	s.job = nil
	writeJSON(w, 200, map[string]bool{"ok": true})
}

func (s *appServer) apiFriends(w http.ResponseWriter) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.client == nil && !s.demo {
		writeError(w, 409, "Not connected to League.")
		return
	}
	out := make([]Friend, len(s.friends))
	copy(out, s.friends)
	for i := range out {
		out[i].Protected = s.protected[out[i].Key]
	}
	writeJSON(w, 200, map[string]any{"friends": out, "riotActivityAvailable": s.hasRiotActivity, "demo": s.demo})
}

func (s *appServer) apiRefresh(w http.ResponseWriter) {
	s.mu.Lock()
	if s.busy {
		s.mu.Unlock()
		writeError(w, 409, "Deletion in progress.")
		return
	}
	c, demo := s.client, s.demo
	s.mu.Unlock()
	if demo {
		s.apiFriends(w)
		return
	}
	if c == nil {
		writeError(w, 409, "Not connected.")
		return
	}
	if !c.sameSession() {
		writeError(w, 409, "League restarted. Select its new lockfile and reconnect.")
		return
	}
	rows, err := c.getFriends()
	if err != nil {
		writeError(w, 502, err.Error())
		return
	}
	riot, available := getRiotFriends()
	friends := normalizeFriends(rows, riot, time.Now())
	s.mu.Lock()
	if s.busy || s.client != c {
		s.mu.Unlock()
		writeError(w, 409, "Client operation changed while refreshing. Please retry.")
		return
	}
	s.friends = friends
	s.hasRiotActivity = available
	s.mu.Unlock()
	s.apiFriends(w)
}

func (s *appServer) apiLanguage(w http.ResponseWriter, r *http.Request) {
	var body struct {
		Language string `json:"language"`
	}
	if err := decodeBody(r, &body); err != nil {
		writeError(w, 400, err.Error())
		return
	}
	if body.Language != "ro" && body.Language != "en" {
		writeError(w, 400, "Unknown language")
		return
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	s.language = body.Language
	if err := s.saveSettingsLocked(); err != nil {
		writeError(w, 500, "Cannot save language settings: "+err.Error())
		return
	}
	writeJSON(w, 200, map[string]any{"language": s.language})
}

func (s *appServer) apiProtect(w http.ResponseWriter, r *http.Request) {
	var body struct {
		Keys    []string `json:"keys"`
		Protect bool     `json:"protect"`
	}
	if err := decodeBody(r, &body); err != nil {
		writeError(w, 400, err.Error())
		return
	}
	if len(body.Keys) > 2000 {
		writeError(w, 400, "Too many selected entries")
		return
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.busy {
		writeError(w, 409, "Deletion in progress")
		return
	}
	allowed := map[string]bool{}
	for _, f := range s.friends {
		if f.Key != "" {
			allowed[f.Key] = true
		}
	}
	changed := 0
	for _, key := range body.Keys {
		if allowed[key] {
			if body.Protect {
				s.protected[key] = true
			} else {
				delete(s.protected, key)
			}
			changed++
		}
	}
	if err := s.saveSettingsLocked(); err != nil {
		writeError(w, 500, "Cannot save protected friends: "+err.Error())
		return
	}
	writeJSON(w, 200, map[string]any{"changed": changed})
}

func csvSafe(value string) string {
	if strings.HasPrefix(value, "=") || strings.HasPrefix(value, "+") ||
		strings.HasPrefix(value, "-") || strings.HasPrefix(value, "@") ||
		strings.HasPrefix(value, "\t") || strings.HasPrefix(value, "\r") ||
		strings.HasPrefix(value, "\n") {
		return "'" + value
	}
	return value
}

func (s *appServer) saveCSV(prefix string, rows []Friend) (string, error) {
	stamp := time.Now().Format("2006-01-02_15-04-05")
	var file *os.File
	var name string
	var err error
	for i := 0; i < 500; i++ {
		name = prefix + "_" + stamp
		if i > 0 {
			name += "_" + strconv.Itoa(i)
		}
		name += ".csv"
		file, err = os.OpenFile(filepath.Join(s.backups, name), os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0600)
		if err == nil {
			break
		}
		if !os.IsExist(err) {
			return "", err
		}
	}
	if err != nil {
		return "", err
	}
	defer file.Close()
	// UTF-8 BOM lets Excel display Romanian names and notes correctly.
	if _, err = file.Write([]byte{0xEF, 0xBB, 0xBF}); err != nil {
		return "", err
	}
	writer := csv.NewWriter(file)
	if err = writer.Write([]string{"Riot ID", "Status", "Last Riot online (local time)", "Estimated inactive days", "Group", "Note", "PUUID", "League friend ID", "Protected"}); err != nil {
		return "", err
	}
	for _, f := range rows {
		last := "Unknown"
		if isOnline(f.Availability) {
			last = "Online now"
		} else if f.LastOnlineMs != nil {
			last = time.UnixMilli(*f.LastOnlineMs).Local().Format("2006-01-02 15:04")
		}
		days := "Unknown"
		if f.DaysInactive != nil {
			days = strconv.Itoa(*f.DaysInactive)
		}
		protected := "No"
		if f.Protected {
			protected = "Yes"
		}
		if err = writer.Write([]string{csvSafe(f.Name), csvSafe(f.Availability), last, days, csvSafe(f.Group), csvSafe(f.Note), csvSafe(f.PUUID), csvSafe(f.ID), protected}); err != nil {
			return "", err
		}
	}
	writer.Flush()
	if err = writer.Error(); err != nil {
		return "", err
	}
	return name, nil
}

func (s *appServer) apiExport(w http.ResponseWriter, r *http.Request) {
	var body struct {
		Keys []string `json:"keys"`
	}
	if err := decodeBody(r, &body); err != nil {
		writeError(w, 400, err.Error())
		return
	}
	s.mu.Lock()
	if s.client == nil && !s.demo {
		s.mu.Unlock()
		writeError(w, 409, "Not connected")
		return
	}
	chosen := map[string]bool{}
	for _, key := range body.Keys {
		chosen[key] = true
	}
	out := make([]Friend, 0, len(body.Keys))
	for _, f := range s.friends {
		if chosen[f.Key] {
			f.Protected = s.protected[f.Key]
			out = append(out, f)
		}
	}
	s.mu.Unlock()
	if len(out) == 0 {
		writeError(w, 400, "There are no matching friends to export.")
		return
	}
	filename, err := s.saveCSV("filtered_export", out)
	if err != nil {
		writeError(w, 500, "Export failed: "+err.Error())
		return
	}
	writeJSON(w, 200, map[string]any{"filename": filename, "count": len(out), "url": "/api/backups/" + filename})
}

func (s *appServer) apiDownload(w http.ResponseWriter, r *http.Request) {
	filename := strings.TrimPrefix(r.URL.Path, "/api/backups/")
	if filename == "" || filepath.Base(filename) != filename || !strings.HasSuffix(strings.ToLower(filename), ".csv") {
		writeError(w, 400, "Invalid backup filename")
		return
	}
	path := filepath.Join(s.backups, filename)
	if _, err := os.Stat(path); err != nil {
		writeError(w, 404, "Backup not found")
		return
	}
	w.Header().Set("Content-Type", "text/csv; charset=utf-8")
	w.Header().Set("Content-Disposition", fmt.Sprintf("attachment; filename=%q", filename))
	http.ServeFile(w, r, path)
}

func (s *appServer) apiOpenBackups(w http.ResponseWriter) {
	if runtime.GOOS != "windows" {
		writeError(w, 400, "This button is available on Windows.")
		return
	}
	if err := exec.Command("explorer.exe", s.backups).Start(); err != nil {
		writeError(w, 500, "Could not open backups folder: "+err.Error())
		return
	}
	writeJSON(w, 200, map[string]bool{"ok": true})
}

func (s *appServer) apiDelete(w http.ResponseWriter, r *http.Request) {
	var body struct {
		Keys         []string `json:"keys"`
		Confirmation string   `json:"confirmation"`
		Language     string   `json:"language"`
	}
	if err := decodeBody(r, &body); err != nil {
		writeError(w, 400, err.Error())
		return
	}
	if len(body.Keys) == 0 || len(body.Keys) > 2000 {
		writeError(w, 400, "Invalid selection size")
		return
	}
	s.mu.Lock()
	if s.busy {
		s.mu.Unlock()
		writeError(w, 409, "A deletion is already running")
		return
	}
	if s.demo {
		s.mu.Unlock()
		writeError(w, 403, "Deletion is disabled in demo mode")
		return
	}
	if s.client == nil {
		s.mu.Unlock()
		writeError(w, 409, "Not connected")
		return
	}
	selected := map[string]bool{}
	for _, key := range body.Keys {
		selected[key] = true
	}
	targets := make([]Friend, 0, len(selected))
	snapshot := make([]Friend, len(s.friends))
	copy(snapshot, s.friends)
	for i := range snapshot {
		snapshot[i].Protected = s.protected[snapshot[i].Key]
	}
	for _, f := range snapshot {
		if selected[f.Key] && f.Key != "" && f.ID != "" && !f.Protected {
			targets = append(targets, f)
		}
	}
	if len(targets) == 0 {
		s.mu.Unlock()
		writeError(w, 400, "No deletable friends were selected (protected friends are skipped).")
		return
	}
	prefix := "DELETE "
	if body.Language == "ro" {
		prefix = "STERGE "
	} else if body.Language != "en" {
		s.mu.Unlock()
		writeError(w, 400, "Invalid language")
		return
	}
	expected := prefix + strconv.Itoa(len(targets))
	if body.Confirmation != expected {
		s.mu.Unlock()
		writeError(w, 400, "Confirmation does not match the selected count.")
		return
	}
	c, account := s.client, s.account
	job := &deleteJob{jobView: jobView{State: "validating", Total: len(targets), Skipped: []string{}, Failed: []string{}}, cancel: make(chan struct{})}
	s.job = job
	s.busy = true
	s.mu.Unlock()
	go s.performDelete(job, c, account, targets, snapshot)
	writeJSON(w, 202, map[string]any{"started": true, "total": len(targets)})
}

func (s *appServer) updateJob(job *deleteJob, fn func(*jobView)) {
	s.mu.Lock()
	defer s.mu.Unlock()
	fn(&job.jobView)
}

func (s *appServer) performDelete(job *deleteJob, c *localClient, account string, targets, snapshot []Friend) {
	defer func() {
		if recovered := recover(); recovered != nil {
			s.updateJob(job, func(v *jobView) { v.Failed = append(v.Failed, "Unexpected internal error; operation stopped") })
		}
		if c.sameSession() {
			raw, err := c.getFriends()
			if err == nil {
				riot, available := getRiotFriends()
				rows := normalizeFriends(raw, riot, time.Now())
				s.mu.Lock()
				if s.client == c {
					s.friends = rows
					s.hasRiotActivity = available
				}
				s.mu.Unlock()
			}
		}
		s.mu.Lock()
		if job.State != "cancelled" {
			job.State = "finished"
		}
		if job.Deleted > 0 {
			job.Signature = signature
		}
		s.busy = false
		s.mu.Unlock()
	}()
	if !c.sameSession() {
		s.updateJob(job, func(v *jobView) { v.Failed = append(v.Failed, "League client restarted or lockfile changed") })
		return
	}
	if account != "" && c.accountIdentity() != account {
		s.updateJob(job, func(v *jobView) { v.Failed = append(v.Failed, "League account changed. No friends were removed") })
		return
	}
	current, err := c.getFriends()
	if err != nil {
		s.updateJob(job, func(v *jobView) { v.Failed = append(v.Failed, "Cannot verify fresh friend list: "+err.Error()) })
		return
	}
	fresh := map[string]map[string]any{}
	for _, f := range current {
		if id := strField(f["id"]); id != "" {
			fresh[id] = f
		}
	}
	// The full friend list is saved BEFORE the first deletion is sent.
	filename, err := s.saveCSV("BACKUP_before_delete", snapshot)
	if err != nil {
		s.updateJob(job, func(v *jobView) { v.Failed = append(v.Failed, "Cannot create backup: "+err.Error()) })
		return
	}
	s.updateJob(job, func(v *jobView) { v.Backup = filename; v.State = "deleting" })
	for index, f := range targets {
		select {
		case <-job.cancel:
			s.updateJob(job, func(v *jobView) { v.State = "cancelled" })
			return
		default:
		}
		if !c.sameSession() {
			s.updateJob(job, func(v *jobView) { v.Failed = append(v.Failed, "League client restarted; remaining deletions stopped") })
			return
		}
		if index > 0 && index%10 == 0 && account != "" && c.accountIdentity() != account {
			s.updateJob(job, func(v *jobView) { v.Failed = append(v.Failed, "League account changed; remaining deletions stopped") })
			return
		}
		entry, exists := fresh[f.ID]
		if !exists || (f.PUUID != "" && !strings.EqualFold(strField(entry["puuid"]), f.PUUID)) {
			s.updateJob(job, func(v *jobView) {
				v.Skipped = append(v.Skipped, f.Name+" — identity not found / changed")
				v.Processed++
			})
			continue
		}
		s.updateJob(job, func(v *jobView) { v.Current = f.Name })
		err := c.removeFriend(f.ID)
		if err != nil {
			s.updateJob(job, func(v *jobView) { v.Failed = append(v.Failed, f.Name+" — "+err.Error()); v.Processed++ })
			if strings.Contains(err.Error(), "HTTP 401") || strings.Contains(err.Error(), "HTTP 403") || strings.Contains(err.Error(), "HTTP 429") || strings.Contains(err.Error(), "HTTP 50") {
				return
			}
		} else {
			s.updateJob(job, func(v *jobView) { v.Deleted++; v.Processed++ })
		}
		if index < len(targets)-1 {
			select {
			case <-job.cancel:
				s.updateJob(job, func(v *jobView) { v.State = "cancelled" })
				return
			case <-time.After(300 * time.Millisecond):
			}
		}
	}
}

func (s *appServer) apiJob(w http.ResponseWriter) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.job == nil {
		writeJSON(w, 200, map[string]any{"state": "idle"})
		return
	}
	j := s.job.jobView
	j.Failed = append([]string{}, j.Failed...)
	j.Skipped = append([]string{}, j.Skipped...)
	writeJSON(w, 200, j)
}

func (s *appServer) apiCancel(w http.ResponseWriter) {
	s.mu.Lock()
	j := s.job
	busy := s.busy
	s.mu.Unlock()
	if j != nil && busy {
		j.once.Do(func() { close(j.cancel) })
	}
	writeJSON(w, 200, map[string]bool{"ok": true})
}

var errNoPicker = errors.New("No file was selected.")

func pickLockfile() (string, error) {
	if runtime.GOOS != "windows" {
		return "", errors.New("File picker requires Windows. Paste a full path instead.")
	}
	script := `Add-Type -AssemblyName System.Windows.Forms; [Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false); $d = New-Object System.Windows.Forms.OpenFileDialog; $d.Title = 'Choose League of Legends lockfile'; $d.Filter = 'All files (*.*)|*.*'; $d.FileName = 'lockfile'; if ($d.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) { [Console]::Write($d.FileName) }`
	cmd := exec.Command("powershell.exe", "-NoProfile", "-STA", "-Command", script)
	output, err := cmd.Output()
	if err != nil {
		return "", fmt.Errorf("Windows file picker failed: %w", err)
	}
	path := strings.TrimSpace(string(output))
	if path == "" {
		return "", errNoPicker
	}
	return path, nil
}

func detectLockfile() string {
	if custom := os.Getenv("LEAGUE_LOCKFILE"); custom != "" {
		if _, err := os.Stat(custom); err == nil {
			return custom
		}
	}
	if runtime.GOOS == "windows" {
		script := `Get-CimInstance Win32_Process | Where-Object { $_.Name -in @('LeagueClient.exe','LeagueClientUx.exe') } | Select-Object -First 1 -ExpandProperty ExecutablePath`
		cmd := exec.Command("powershell.exe", "-NoProfile", "-NonInteractive", "-Command", script)
		output, err := cmd.Output()
		if err == nil {
			candidate := filepath.Join(filepath.Dir(strings.TrimSpace(string(output))), "lockfile")
			if _, err = os.Stat(candidate); err == nil {
				return candidate
			}
		}
		for _, drive := range "CDEFGHIJKL" {
			for _, p := range []string{"Riot Games\\League of Legends\\lockfile", "Program Files\\Riot Games\\League of Legends\\lockfile", "Program Files (x86)\\Riot Games\\League of Legends\\lockfile"} {
				candidate := string(drive) + ":\\" + p
				if _, err := os.Stat(candidate); err == nil {
					return candidate
				}
			}
		}
	}
	return ""
}
