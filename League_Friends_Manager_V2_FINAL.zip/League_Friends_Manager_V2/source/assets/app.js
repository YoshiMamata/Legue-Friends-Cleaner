'use strict';
const TOKEN = document.querySelector('meta[name="lfm-token"]').content;
const $ = (id) => document.getElementById(id);
const selected = new Set();
let friends = [];
let filtered = [];
let language = 'en';
let demo = false;
let activityAvailable = false;
let busy = false;
let modalMode = '';
let expectedConfirmation = '';
let deleteKeys = [];
let polling = null;
let lastJob = null;

const texts = {
  en: {
    localOnly:'● Local-only', exit:'Exit app',welcome:'WELCOME TO V2',
    gateTitle:'A cleaner friend list.\nA better League experience.',
    gateIntro:'Choose your League Client lockfile first. Your friends are only loaded after the local connection is verified.',
    featSearch:'⚡ Fast filters',featBackup:'◈ CSV safety backup',featPrivacy:'⌁ Local connection',
    step1:'CONNECT TO LEAGUE',lockTitle:'Locate your lockfile',
    lockExplainer:'Keep League of Legends open and signed in. The file is usually named exactly “lockfile”, without an extension.',
    lockPath:'Lockfile location',browse:'Browse…',autoDetect:'Auto-detect League lockfile',
    connect:'Connect & load friends',gateHint:'Your local lockfile password never leaves your computer.',
    workspace:'YOUR WORKSPACE',dashboardTitle:'Friends, organized.',changeClient:'Change lockfile',refresh:'↻ Refresh list',
    totalFriends:'TOTAL FRIENDS',leagueFriends:'League Client contacts',onlineNow:'ONLINE NOW',
    onlineDescription:'Online, away, in game or mobile',unknownActivity:'UNKNOWN ACTIVITY',
    unknownDescription:'Never assumed inactive',protectedFriends:'PROTECTED FRIENDS',protectedDescription:'Excluded from bulk deletion',
    friendList:'Friend list',activityDisclaimer:'Activity refers to Riot’s last online timestamp (when available), not the last League match.',
    search:'Search',searchPlaceholder:'Riot ID, note, group…',status:'Status',activity:'Activity',group:'Group',sort:'Sort by',
    visibleOf:'visible',selected:'selected',selectVisible:'Select filtered',clearSelection:'Clear selection',
    protect:'☆ Protect',unprotect:'Remove protection',
    colName:'RIOT ID',colStatus:'STATUS',colLast:'LAST RIOT ONLINE',colDays:'DAYS',colGroup:'GROUP',colNote:'NOTE',
    empty:'No friends match these filters.',export:'⇩ Export filtered CSV',backups:'Open backups folder',delete:'Delete selected',
    legal:"League Friends Manager isn't endorsed by Riot Games and doesn't reflect the views or opinions of Riot Games or anyone officially involved in producing or managing Riot Games properties. Riot Games, and all associated properties are trademarks or registered trademarks of Riot Games, Inc.",
    all:'All',online:'Online',offline:'Offline',unknown:'Unknown',any:'Any',
    inactive7:'Inactive ≥7 days',inactive30:'Inactive ≥30 days',inactive90:'Inactive ≥90 days',inactive180:'Inactive ≥180 days',unknownDate:'Unknown date',
    allGroups:'All groups',az:'Name A–Z',za:'Name Z–A',recent:'Recent → old',old:'Old → recent',groupSort:'Group A–Z',
    connectedTo:'Connected to League Client',demoLabel:'DEMO MODE — fictional friends; deletion disabled',
    available:'Riot activity available',unavailable:'Riot activity unavailable',onlineDate:'Online now',unknownValue:'Unknown',
    protectDone:'Protection updated for {n} friend(s).',chooseFirst:'Please select a lockfile.',
    detecting:'Looking for the League lockfile…',detected:'Found League lockfile. Click Connect.',
    notDetected:'Auto-detect could not find the lockfile. Use Browse or paste its full path.',
    connecting:'Connecting to the League Client…',connectSuccess:'Connected! Loaded {n} friends.',
    refreshing:'Refreshing friends…',refreshed:'Friend list refreshed.',
    selectedNone:'Select at least one friend first.',nothingToExport:'No filtered friends to export.',
    exported:'CSV exported and saved to your backups folder.',
    protectedOnly:'All selected friends are protected or cannot be deleted.',
    confirmEyebrow:'SAFETY CHECK',confirmTitle:'Confirm bulk deletion',
    confirmDescription:'You are about to remove {n} friend(s). {protected} protected selections will be skipped. A full CSV backup is created before any deletion. This cannot be automatically undone.',
    confirmLabel:'Type exactly “{phrase}” to continue',confirm:'Delete {n} friend(s)',cancel:'Cancel',
    runningEyebrow:'CLEANING IN PROGRESS',runningTitle:'Your friend list is being cleaned',
    runningDescription:'Leave League open. One friend is processed at a time, with a short pause between requests.',
    cancelRemaining:'Stop remaining',validating:'Verifying identity & saving backup…',deletingNow:'Deleting: {name}',
    processing:'Processed {done} of {total} • removed {deleted}',
    resultEyebrow:'FINISHED',resultTitle:'Cleaning result',resultDescription:'Operation finished. Here is what happened:',
    resultLines:'Deleted: {deleted}\nFailed: {failed}\nSkipped: {skipped}',
    backupFilename:'Backup: {name}',downloadBackup:'Download CSV backup',done:'Done',
    cancelled:'Remaining deletions were cancelled.',noBackup:'No deletion started; no backup needed.',
    viewErrors:'Details:\n{list}',close:'Close',unknownError:'Something went wrong.',
    farewell:'Close the CMD window to stop the program. Goodbye!',
    footerSignature:'Cleaned by YoshiMamata#MUE',
  },
  ro: {
    localOnly:'● Doar local',exit:'Închide aplicația',welcome:'BINE AI VENIT LA V2',
    gateTitle:'O listă de prieteni curată.\nO experiență League mai bună.',
    gateIntro:'Mai întâi selectează lockfile-ul League Client. Prietenii se încarcă doar după validarea conexiunii locale.',
    featSearch:'⚡ Filtre rapide',featBackup:'◈ Backup CSV sigur',featPrivacy:'⌁ Conexiune locală',
    step1:'CONECTARE LA LEAGUE',lockTitle:'Localizează lockfile-ul',
    lockExplainer:'Ține League of Legends pornit și autentificat. Fișierul se numește de obicei exact „lockfile”, fără extensie.',
    lockPath:'Locația fișierului lockfile',browse:'Răsfoiește…',autoDetect:'Detectează automat lockfile-ul League',
    connect:'Conectează și încarcă prietenii',gateHint:'Parola locală din lockfile nu părăsește calculatorul.',
    workspace:'SPAȚIUL TĂU DE LUCRU',dashboardTitle:'Prietenii, organizați.',changeClient:'Schimbă lockfile',refresh:'↻ Actualizează lista',
    totalFriends:'TOTAL PRIETENI',leagueFriends:'Contacte League Client',onlineNow:'ONLINE ACUM',
    onlineDescription:'Online, absent, în joc sau mobil',unknownActivity:'ACTIVITATE NECUNOSCUTĂ',
    unknownDescription:'Nu sunt considerați automat inactivi',protectedFriends:'PRIETENI PROTEJAȚI',protectedDescription:'Excluși de la ștergerea în masă',
    friendList:'Lista de prieteni',activityDisclaimer:'Activitatea indică ultima conectare Riot (când e disponibilă), nu ultimul meci League.',
    search:'Caută',searchPlaceholder:'Riot ID, notă, grup…',status:'Status',activity:'Activitate',group:'Grup',sort:'Ordonează',
    visibleOf:'afișați',selected:'selectați',selectVisible:'Selectează filtrații',clearSelection:'Deselectează',
    protect:'☆ Protejează',unprotect:'Elimină protecția',
    colName:'RIOT ID',colStatus:'STATUS',colLast:'ULTIMA CONECTARE RIOT',colDays:'ZILE',colGroup:'GRUP',colNote:'NOTĂ',
    empty:'Niciun prieten nu corespunde filtrelor.',export:'⇩ Exportă CSV filtrat',backups:'Deschide backup-urile',delete:'Șterge selectații',
    legal:'League Friends Manager nu este susținut sau aprobat de Riot Games și nu reflectă opiniile Riot Games sau ale persoanelor implicate oficial în realizarea sau administrarea produselor Riot Games. Riot Games și proprietățile sale sunt mărci comerciale sau mărci înregistrate ale Riot Games, Inc.',
    all:'Toți',online:'Online',offline:'Offline',unknown:'Necunoscut',any:'Oricare',
    inactive7:'Inactiv ≥7 zile',inactive30:'Inactiv ≥30 zile',inactive90:'Inactiv ≥90 zile',inactive180:'Inactiv ≥180 zile',unknownDate:'Dată necunoscută',
    allGroups:'Toate grupurile',az:'Nume A–Z',za:'Nume Z–A',recent:'Recent → vechi',old:'Vechi → recent',groupSort:'Grup A–Z',
    connectedTo:'Conectat la League Client',demoLabel:'MOD DEMO — prieteni fictivi; ștergerea este dezactivată',
    available:'Activitatea Riot este disponibilă',unavailable:'Activitatea Riot nu este disponibilă',onlineDate:'Conectat acum',unknownValue:'Necunoscut',
    protectDone:'Protecția a fost actualizată pentru {n} prieten(i).',chooseFirst:'Selectează mai întâi un lockfile.',
    detecting:'Caut lockfile-ul League…',detected:'Lockfile găsit. Apasă Conectează.',
    notDetected:'Nu am găsit automat lockfile-ul. Apasă Răsfoiește sau introdu calea completă.',
    connecting:'Mă conectez la League Client…',connectSuccess:'Conectat! Am încărcat {n} prieteni.',
    refreshing:'Actualizez lista…',refreshed:'Lista de prieteni a fost actualizată.',
    selectedNone:'Selectează întâi cel puțin un prieten.',nothingToExport:'Nu există prieteni filtrați de exportat.',
    exported:'CSV exportat și salvat în folderul de backup.',
    protectedOnly:'Toți prietenii selectați sunt protejați sau nu pot fi șterși.',
    confirmEyebrow:'VERIFICARE DE SIGURANȚĂ',confirmTitle:'Confirmă ștergerea în masă',
    confirmDescription:'Urmează să elimini {n} prieten(i). {protected} selecții protejate vor fi omise. Se creează un backup CSV complet înainte de orice ștergere. Operațiunea nu poate fi anulată automat.',
    confirmLabel:'Tastează exact „{phrase}” pentru a continua',confirm:'Șterge {n} prieten(i)',cancel:'Anulează',
    runningEyebrow:'CURĂȚARE ÎN DESFĂȘURARE',runningTitle:'Lista de prieteni este curățată',
    runningDescription:'Ține League deschis. Prietenii sunt procesați pe rând, cu o scurtă pauză între cereri.',
    cancelRemaining:'Oprește restul',validating:'Verific identitatea și creez backup…',deletingNow:'Șterg: {name}',
    processing:'Procesați {done} din {total} • eliminați {deleted}',
    resultEyebrow:'FINALIZAT',resultTitle:'Rezultatul curățării',resultDescription:'Operațiunea s-a încheiat. Iată rezultatul:',
    resultLines:'Șterși: {deleted}\nEșuați: {failed}\nOmiși: {skipped}',
    backupFilename:'Backup: {name}',downloadBackup:'Descarcă backup-ul CSV',done:'Gata',
    cancelled:'Restul ștergerilor au fost anulate.',noBackup:'Nu a început nicio ștergere; nu a fost necesar backup.',
    viewErrors:'Detalii:\n{list}',close:'Închide',unknownError:'A apărut o eroare.',
    farewell:'Închide fereastra CMD pentru a opri programul. Pe curând!',
    footerSignature:'Cleaned by YoshiMamata#MUE',
  }
};
function t(key, args={}) {
  const message = (texts[language] && texts[language][key]) || texts.en[key] || key;
  return message.replace(/\{([a-zA-Z]+)\}/g,(_,name)=>String(args[name]??''));
}
function translate() {
  document.documentElement.lang = language;
  document.querySelectorAll('[data-i18n]').forEach(el=>el.textContent=t(el.dataset.i18n));
  document.querySelectorAll('[data-i18n-placeholder]').forEach(el=>el.placeholder=t(el.dataset.i18nPlaceholder));
  $('languageButton').textContent = language==='en'?'RO':'EN';
  const setOptions = (id, keys) => { const opts=$(id).options; keys.forEach((key,i)=>opts[i].textContent=t(key)); };
  setOptions('statusFilter',['all','online','offline','unknown']);
  setOptions('activityFilter',['any','inactive7','inactive30','inactive90','inactive180','unknownDate']);
  setOptions('sortFilter',['az','za','recent','old','groupSort']);
  $('groupFilter').options[0].textContent=t('allGroups');
  updateTop();
  render();
}
async function api(route,method='GET',body) {
  const opts={method,headers:{'X-LFM-Session':TOKEN}};
  if(body!==undefined){opts.headers['Content-Type']='application/json';opts.body=JSON.stringify(body);}
  let response;
  try { response=await fetch('/api/'+route,opts); }
  catch (_) { throw Error(language==='ro'?'Conexiunea locală a fost întreruptă.':'Local app connection was interrupted.'); }
  const data=await response.json().catch(()=>({}));
  if(!response.ok)throw Error(data.error||t('unknownError'));
  return data;
}
let toastTimer=0;
function toast(message,error=false) {
  const box=$('toast');box.textContent=message;box.classList.toggle('error',error);box.classList.remove('hidden');
  window.clearTimeout(toastTimer);toastTimer=window.setTimeout(()=>box.classList.add('hidden'),5000);
}
function gateMessage(message,type='') {
  $('gateInfo').textContent=message;
  $('gateInfo').className='helper-message '+type;
}
function showDashboard(on) {$('gate').classList.toggle('hidden',on);$('dashboard').classList.toggle('hidden',!on);}
function updateTop() {
  $('connectionNote').textContent = demo?t('demoLabel'):t('connectedTo');
  $('activityBadge').textContent=t(activityAvailable?'available':'unavailable');
  $('activityBadge').classList.toggle('unavailable',!activityAvailable);
}
function getVisible() {
  const q=$('searchInput').value.trim().toLocaleLowerCase();
  const status=$('statusFilter').value,activity=$('activityFilter').value,group=$('groupFilter').value,sort=$('sortFilter').value;
  const list=friends.filter(f=>{
    if(q && !`${f.name} ${f.group} ${f.note}`.toLocaleLowerCase().includes(q))return false;
    if(status!=='all' && f.status!==status)return false;
    if(group!=='all' && f.group!==group)return false;
    if(activity==='unknown' && f.daysInactive!==null)return false;
    if(activity!=='all'&&activity!=='unknown'&&(f.daysInactive===null || f.daysInactive<Number(activity)))return false;
    return true;
  });
  const compare=(a,b)=>a.localeCompare(b,language,{sensitivity:'base',numeric:true});
  list.sort((a,b)=>{
    if(sort==='za')return compare(b.name,a.name);
    if(sort==='recent'||sort==='old'){
      if(a.activityMs===null&&b.activityMs!==null)return 1;
      if(b.activityMs===null&&a.activityMs!==null)return -1;
      if(a.activityMs!==null&&b.activityMs!==null&&a.activityMs!==b.activityMs)
        return sort==='recent'?b.activityMs-a.activityMs:a.activityMs-b.activityMs;
    }
    if(sort==='group'){const g=compare(a.group,b.group);if(g)return g;}
    return compare(a.name,b.name);
  });
  return list;
}
function updateGroups(){
  const box=$('groupFilter'),previous=box.value;
  while(box.options.length>1)box.remove(1);
  [...new Set(friends.map(f=>f.group))].sort((a,b)=>a.localeCompare(b,language)).forEach(g=>{
    const option=document.createElement('option');option.value=g;option.textContent=g;box.appendChild(option);
  });
  box.value=[...box.options].some(o=>o.value===previous)?previous:'all';
}
function displayDate(f){
  if(['chat','dnd','away','mobile'].includes(f.availability))return t('onlineDate');
  if(f.lastOnlineMs===null)return t('unknownValue');
  return new Intl.DateTimeFormat(language==='ro'?'ro-RO':'en-GB',{year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit'}).format(new Date(f.lastOnlineMs));
}
function appendCell(tr,value,cls='') {
  const td=document.createElement('td');if(cls)td.className=cls;
  td.textContent=value;tr.appendChild(td);return td;
}
function render(){
  if(!Array.isArray(friends))return;
  filtered=getVisible();
  const tbody=$('friendsTable');tbody.replaceChildren();
  const fragment=document.createDocumentFragment();
  for(const f of filtered) {
    const tr=document.createElement('tr');
    if(selected.has(f.key))tr.className='is-checked';
    const td=appendCell(tr,'','check-col');
    const chk=document.createElement('input');chk.type='checkbox';chk.checked=selected.has(f.key);chk.disabled=!f.key||!f.id||busy;
    chk.setAttribute('aria-label',`Select ${f.name}`);
    chk.addEventListener('change',()=>{if(chk.checked)selected.add(f.key);else selected.delete(f.key);render();});
    td.appendChild(chk);
    const nameTd=appendCell(tr,'');const nameSpan=document.createElement('span');nameSpan.className='name';nameSpan.textContent=f.name;nameTd.appendChild(nameSpan);
    if(f.protected){const star=document.createElement('span');star.textContent='★';star.className='friend-tag';star.title=t('protectedFriends');nameTd.appendChild(star);}
    const statusTd=appendCell(tr,'');const status=document.createElement('span');status.className='status status-'+f.status;status.textContent=t(f.status);statusTd.appendChild(status);
    appendCell(tr,displayDate(f),f.lastOnlineMs===null&&f.status!=='online'?'table-muted':'');
    const daysTd=appendCell(tr,'');const days=document.createElement('span');days.className='days-chip'+(f.daysInactive!==null&&f.daysInactive>=90?' stale':'');days.textContent=f.daysInactive===null?'—':String(f.daysInactive);daysTd.appendChild(days);
    appendCell(tr,f.group);appendCell(tr,f.note||'—','table-muted');
    fragment.appendChild(tr);
  }
  tbody.appendChild(fragment);
  $('emptyMessage').classList.toggle('hidden',filtered.length!==0);
  $('displayCount').textContent=filtered.length+' / '+friends.length;
  $('selectedCount').textContent=selected.size;
  $('totalCount').textContent=friends.length;
  $('onlineCount').textContent=friends.filter(f=>f.status==='online').length;
  $('unknownCount').textContent=friends.filter(f=>f.daysInactive===null).length;
  $('protectedCount').textContent=friends.filter(f=>f.protected).length;
  const eligible=filtered.filter(f=>f.key&&f.id);
  $('headerCheck').checked=eligible.length>0&&eligible.every(f=>selected.has(f.key));
  $('headerCheck').indeterminate=eligible.some(f=>selected.has(f.key))&&!$('headerCheck').checked;
  $('headerCheck').disabled=busy||eligible.length===0;
  for(const id of ['refreshButton','changeButton','selectVisible','clearSelected','protectSelected','unprotectSelected','exportButton','backupsButton','deleteButton','exitButton']) {
    $(id).disabled=busy;
  }
  $('deleteButton').disabled=busy||demo||selected.size===0;
  $('protectSelected').disabled=busy||selected.size===0;
  $('unprotectSelected').disabled=busy||selected.size===0;
}
async function loadFriends() {
  const data=await api('friends');friends=data.friends||[];demo=data.demo;activityAvailable=data.riotActivityAvailable;
  const valid=new Set(friends.map(f=>f.key));for(const key of [...selected])if(!valid.has(key))selected.delete(key);
  updateGroups();updateTop();render();
}
async function switchLanguage() {
  const next=language==='en'?'ro':'en';
  try{await api('language','POST',{language:next});language=next;translate();}
  catch(error){toast(error.message,true);}
}
async function detect() {
  gateMessage(t('detecting'));
  try{const result=await api('locate');if(result.found){$('lockPath').value=result.path;gateMessage(t('detected'),'success');}
  else{gateMessage(t('notDetected'),'error');}}
  catch(error){gateMessage(error.message,'error');}
}
async function browse(){
  gateMessage(t('gateHint'));
  try{const result=await api('pick','POST',{});$('lockPath').value=result.path;gateMessage(t('detected'),'success');}
  catch(error){if(!/No file was selected/.test(error.message))gateMessage(error.message,'error');}
}
async function connect(){
  const path=$('lockPath').value.trim();if(!path){gateMessage(t('chooseFirst'),'error');return;}
  gateMessage(t('connecting'));$('connectButton').disabled=true;
  try{const result=await api('connect','POST',{path});selected.clear();await loadFriends();showDashboard(true);toast(t('connectSuccess',{n:result.count}));}
  catch(error){gateMessage(error.message,'error');}finally{$('connectButton').disabled=false;}
}
async function changeClient(){
  try{await api('disconnect','POST',{});friends=[];selected.clear();showDashboard(false);gateMessage(t('gateHint'));}
  catch(error){toast(error.message,true);}
}
async function refresh(){
  toast(t('refreshing'));
  try{await api('refresh','POST',{});await loadFriends();toast(t('refreshed'));}
  catch(error){toast(error.message,true);}
}
async function protect(protectMode){
  if(selected.size===0){toast(t('selectedNone'),true);return;}
  try{const result=await api('protect','POST',{keys:[...selected],protect:protectMode});await loadFriends();toast(t('protectDone',{n:result.changed}));}
  catch(error){toast(error.message,true);}
}
async function exportFiltered(){
  if(filtered.length===0){toast(t('nothingToExport'),true);return;}
  try{
    const result=await api('export','POST',{keys:filtered.map(f=>f.key).filter(Boolean)});
    const response=await fetch(result.url,{headers:{'X-LFM-Session':TOKEN}});
    if(!response.ok)throw Error('CSV download failed');
    const blob=await response.blob(),url=URL.createObjectURL(blob);
    const a=document.createElement('a');a.href=url;a.download=result.filename;document.body.appendChild(a);a.click();a.remove();
    setTimeout(()=>URL.revokeObjectURL(url),1000);toast(t('exported'));
  }catch(error){toast(error.message,true);}
}
function showModal(){ $('modal').classList.remove('hidden');$('modalClose').focus(); }
function closeModal(){
  if(modalMode==='progress')return;
  $('modal').classList.add('hidden');modalMode='';
}
function openDelete(){
  const targets=friends.filter(f=>selected.has(f.key)&&f.key&&f.id&&!f.protected);
  if(!targets.length){toast(t('protectedOnly'),true);return;}
  const excluded=[...selected].length-targets.length;
  deleteKeys=targets.map(f=>f.key);
  expectedConfirmation=(language==='ro'?'STERGE ':'DELETE ')+targets.length;
  modalMode='confirm';
  $('modalEyebrow').textContent=t('confirmEyebrow');$('modalTitle').textContent=t('confirmTitle');
  $('modalDescription').textContent=t('confirmDescription',{n:targets.length,protected:excluded});
  $('modalNames').textContent=targets.slice(0,12).map(f=>'• '+f.name).join('\n')+(targets.length>12?'\n… +'+(targets.length-12):'');
  $('confirmationBox').classList.remove('hidden');$('progressBox').classList.add('hidden');
  $('confirmationLabel').textContent=t('confirmLabel',{phrase:expectedConfirmation});
  $('confirmationInput').value='';$('modalSummary').replaceChildren();
  $('modalCancel').textContent=t('cancel');$('modalCancel').classList.remove('hidden');
  $('modalConfirm').textContent=t('confirm',{n:targets.length});$('modalConfirm').className='button button-danger';$('modalConfirm').classList.remove('hidden');$('modalConfirm').disabled=true;
  $('modalClose').classList.remove('hidden');showModal();$('confirmationInput').focus();
}
async function startDelete(){
  if($('confirmationInput').value!==expectedConfirmation)return;
  try{
    await api('delete','POST',{keys:deleteKeys,confirmation:expectedConfirmation,language});
    modalMode='progress';busy=true;render();
    $('modalEyebrow').textContent=t('runningEyebrow');$('modalTitle').textContent=t('runningTitle');$('modalDescription').textContent=t('runningDescription');
    $('confirmationBox').classList.add('hidden');$('modalNames').textContent='';$('progressBox').classList.remove('hidden');
    $('modalCancel').textContent=t('cancelRemaining');$('modalCancel').classList.remove('hidden');
    $('modalConfirm').classList.add('hidden');$('modalClose').classList.add('hidden');
    $('modalSummary').replaceChildren();$('progressBar').style.width='0%';$('progressText').textContent=t('validating');
    await pollJob();if(modalMode==='progress')polling=window.setInterval(pollJob,650);
  }catch(error){toast(error.message,true);}
}
async function pollJob(){
  try{
    const job=await api('job');lastJob=job;
    if(modalMode!=='progress')return;
    $('progressBar').style.width=(job.total?Math.round(100*job.processed/job.total):0)+'%';
    $('progressText').textContent=job.state==='validating'?t('validating'):
      t('processing',{done:job.processed,total:job.total,deleted:job.deleted})+(job.current?' — '+t('deletingNow',{name:job.current}):'');
    if(job.state==='finished'||job.state==='cancelled'){
      clearInterval(polling);polling=null;busy=false;selected.clear();await loadFriends();showResults(job);
    }
  }catch(error){
    clearInterval(polling);polling=null;busy=false;render();
    modalMode='result';$('modalTitle').textContent=t('unknownError');$('modalDescription').textContent=error.message;
    $('modalClose').classList.remove('hidden');$('modalCancel').classList.add('hidden');$('modalConfirm').classList.remove('hidden');$('modalConfirm').disabled=false;$('modalConfirm').textContent=t('done');
  }
}
function showResults(job){
  modalMode='result';$('modalEyebrow').textContent=t('resultEyebrow');$('modalTitle').textContent=t('resultTitle');
  $('modalDescription').textContent=t('resultDescription');$('confirmationBox').classList.add('hidden');$('progressBox').classList.add('hidden');
  $('modalClose').classList.remove('hidden');$('modalCancel').classList.add('hidden');$('modalConfirm').classList.remove('hidden');
  $('modalConfirm').textContent=t('done');$('modalConfirm').className='button button-primary';$('modalConfirm').disabled=false;
  const box=$('modalSummary');box.replaceChildren();
  const summary=document.createElement('p');summary.textContent=t('resultLines',{deleted:job.deleted,failed:(job.failed||[]).length,skipped:(job.skipped||[]).length});box.appendChild(summary);
  if(job.state==='cancelled'){const p=document.createElement('p');p.textContent=t('cancelled');box.appendChild(p);}
  if(job.backup){const p=document.createElement('p');p.textContent=t('backupFilename',{name:job.backup});box.appendChild(p);
    const link=document.createElement('a');link.href='#';link.textContent=t('downloadBackup');
    link.addEventListener('click',async e=>{e.preventDefault();try{
      const response=await fetch('/api/backups/'+job.backup,{headers:{'X-LFM-Session':TOKEN}});
      if(!response.ok)throw Error('CSV download failed');const blob=await response.blob();const url=URL.createObjectURL(blob);
      const anchor=document.createElement('a');anchor.href=url;anchor.download=job.backup;anchor.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
    }catch(err){toast(err.message,true);}});box.appendChild(link);
  }else{const p=document.createElement('p');p.textContent=t('noBackup');box.appendChild(p);}
  const errs=[...(job.failed||[]),...(job.skipped||[])];if(errs.length){const p=document.createElement('p');p.textContent=t('viewErrors',{list:errs.slice(0,12).join('\n')});box.appendChild(p);}
  if(job.deleted>0){const sig=document.createElement('p');sig.className='signature';sig.textContent=t('footerSignature');box.appendChild(sig);$('cleanSignature').classList.remove('hidden');}
}
async function cancelRemaining(){
  try{await api('cancel','POST',{});$('modalCancel').disabled=true;}
  catch(error){toast(error.message,true);}
}
function attach(){
  $('languageButton').addEventListener('click',switchLanguage);
  $('exitButton').addEventListener('click',async()=>{try{await api('exit','POST',{});toast(t('farewell'));}catch(error){toast(error.message,true);}});
  $('detectButton').addEventListener('click',detect);$('browseButton').addEventListener('click',browse);
  $('connectButton').addEventListener('click',connect);$('lockPath').addEventListener('keydown',e=>{if(e.key==='Enter')connect();});
  $('changeButton').addEventListener('click',changeClient);$('refreshButton').addEventListener('click',refresh);
  for(const id of ['searchInput','statusFilter','activityFilter','groupFilter','sortFilter'])$(id).addEventListener('input',render);
  $('selectVisible').addEventListener('click',()=>{filtered.forEach(f=>{if(f.key&&f.id)selected.add(f.key)});render();});
  $('clearSelected').addEventListener('click',()=>{selected.clear();render();});
  $('headerCheck').addEventListener('change',e=>{filtered.forEach(f=>{if(f.key&&f.id){if(e.target.checked)selected.add(f.key);else selected.delete(f.key)}});render();});
  $('protectSelected').addEventListener('click',()=>protect(true));$('unprotectSelected').addEventListener('click',()=>protect(false));
  $('exportButton').addEventListener('click',exportFiltered);
  $('backupsButton').addEventListener('click',async()=>{try{await api('open-backups','POST',{});}catch(error){toast(error.message,true);}});
  $('deleteButton').addEventListener('click',openDelete);
  $('confirmationInput').addEventListener('input',()=>{$('modalConfirm').disabled=$('confirmationInput').value!==expectedConfirmation;});
  $('modalClose').addEventListener('click',closeModal);
  $('modalCancel').addEventListener('click',()=>{if(modalMode==='progress')cancelRemaining();else closeModal();});
  $('modalConfirm').addEventListener('click',()=>{if(modalMode==='confirm')startDelete();else closeModal();});
  document.addEventListener('keydown',e=>{if(e.key==='Escape')closeModal();});
}
async function initialize(){
  attach();
  try{const status=await api('status');language=status.language==='ro'?'ro':'en';demo=status.demo;activityAvailable=status.riotActivityAvailable;translate();
    if(status.lockfile)$('lockPath').value=status.lockfile;
    if(status.connected){await loadFriends();showDashboard(true);}else{showDashboard(false);}
  }catch(error){gateMessage(error.message,'error');}
}
initialize();
