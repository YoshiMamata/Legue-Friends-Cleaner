package main

import (
	"encoding/json"
	"math"
	"sort"
	"strconv"
	"strings"
	"time"
)

type Friend struct {
	ID           string `json:"id"`
	PUUID        string `json:"puuid"`
	Key          string `json:"key"`
	Name         string `json:"name"`
	Availability string `json:"availability"`
	Status       string `json:"status"`
	Group        string `json:"group"`
	Note         string `json:"note"`
	LastOnlineMs *int64 `json:"lastOnlineMs"`
	ActivityMs   *int64 `json:"activityMs"`
	DaysInactive *int   `json:"daysInactive"`
	Protected    bool   `json:"protected"`
}

func isOnline(state string) bool {
	switch strings.ToLower(state) {
	case "chat", "dnd", "away", "mobile":
		return true
	default:
		return false
	}
}

func friendName(data map[string]any) string {
	name := strField(data["gameName"])
	if name == "" {
		name = strField(data["game_name"])
	}
	tag := strField(data["gameTag"])
	if tag == "" {
		tag = strField(data["game_tag"])
	}
	if tag == "" {
		tag = strField(data["tagLine"])
	}
	if name != "" && tag != "" {
		return name + "#" + tag
	}
	if name != "" {
		return name
	}
	if alt := strField(data["name"]); alt != "" {
		return alt
	}
	return "(Unavailable name)"
}

func readTimestamp(v any, now time.Time) *int64 {
	if v == nil {
		return nil
	}
	var num float64
	switch value := v.(type) {
	case string:
		n, err := strconv.ParseFloat(value, 64)
		if err != nil {
			return nil
		}
		num = n
	case json.Number:
		n, err := value.Float64()
		if err != nil {
			return nil
		}
		num = n
	case float64:
		num = value
	default:
		return nil
	}
	if math.IsNaN(num) || math.IsInf(num, 0) || num <= 0 {
		return nil
	}
	if num < 1e11 {
		num *= 1000
	}
	if num < 946684800000 || num > float64(now.Add(48*time.Hour).UnixMilli()) {
		return nil
	}
	ts := int64(num)
	return &ts
}

func normalizeFriends(raw []map[string]any, riot map[string]map[string]any, now time.Time) []Friend {
	rows := make([]Friend, 0, len(raw))
	for _, f := range raw {
		id := strField(f["id"])
		puuid := strField(f["puuid"])
		key := ""
		if puuid != "" {
			key = "p:" + strings.ToLower(puuid)
		} else if id != "" {
			key = "l:" + id
		}
		match := riot[strings.ToLower(puuid)]
		state := strings.ToLower(strField(f["availability"]))
		if state == "" {
			state = "unknown"
		}
		status := "unknown"
		if state == "offline" {
			status = "offline"
		} else if isOnline(state) {
			status = "online"
		}
		group := strField(f["groupName"])
		if group == "" {
			group = strField(match["group"])
		}
		if group == "" {
			group = "—"
		}
		note := strField(f["note"])
		if note == "" {
			note = strField(match["note"])
		}
		name := friendName(f)
		if name == "(Unavailable name)" && match != nil {
			name = friendName(match)
		}
		last := readTimestamp(match["last_online_ts"], now)
		activity := last
		if isOnline(state) {
			ts := now.UnixMilli()
			activity = &ts
		}
		var days *int
		if activity != nil {
			d := int(now.Sub(time.UnixMilli(*activity)).Hours() / 24)
			if d < 0 {
				d = 0
			}
			days = &d
		}
		rows = append(rows, Friend{
			ID: id, PUUID: puuid, Key: key, Name: name, Availability: state,
			Status: status, Group: group, Note: note,
			LastOnlineMs: last, ActivityMs: activity, DaysInactive: days,
		})
	}
	sort.Slice(rows, func(i, j int) bool { return strings.ToLower(rows[i].Name) < strings.ToLower(rows[j].Name) })
	return rows
}

func demoFriends() []Friend {
	now := time.Now()
	samples := []struct {
		n, st, g, note string
		days           int
	}{
		{"Ana#EUW", "chat", "Duo", "Ranked partner", 0},
		{"ZedMain#EUNE", "offline", "General", "", 199},
		{"Mihai#RO1", "offline", "General", "", 33},
		{"BestJungle#777", "dnd", "Duo", "Jungle", 0},
		{"PlayerX#LOL", "offline", "General", "", -1},
		{"OldFriend#123", "offline", "Old friends", "", 410},
		{"Teo#EUNE", "away", "Duo", "", 0},
		{"Riven#1", "offline", "Old friends", "", 7},
	}
	out := make([]Friend, 0, len(samples))
	for i, s := range samples {
		f := Friend{ID: "demo-" + strconv.Itoa(i), PUUID: "demo-puuid-" + strconv.Itoa(i), Key: "p:demo-puuid-" + strconv.Itoa(i), Name: s.n, Availability: s.st, Group: s.g, Note: s.note}
		if isOnline(s.st) {
			f.Status = "online"
			t := now.UnixMilli()
			f.ActivityMs = &t
			d := 0
			f.DaysInactive = &d
		} else {
			f.Status = "offline"
			if s.days >= 0 {
				t := now.Add(time.Duration(-s.days) * 24 * time.Hour).UnixMilli()
				f.LastOnlineMs = &t
				f.ActivityMs = &t
				d := s.days
				f.DaysInactive = &d
			}
		}
		out = append(out, f)
	}
	return out
}
