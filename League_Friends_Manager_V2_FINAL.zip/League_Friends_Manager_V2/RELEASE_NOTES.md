# League Friends Manager V2 — Release Notes

- Native Windows x64 executable; Python and Go are not required at runtime.
- CMD launch, automatic default-browser opening, loopback-only local web interface.
- Mandatory League lockfile selection before entering the real dashboard (auto-detect, browse, manual path).
- Romanian and English UI with saved preference, plus both README translations.
- V1-style search, status/activity/group filters and sorting.
- Persistent protected contacts, CSV exports, full backup before deletion.
- Batch deletion with explicit typed confirmation, fresh identity verification, progress, and cancel remaining.
- Optional Riot Client last-online timestamp; unknown dates remain unknown.
- Fictional, deletion-disabled demo mode.
- Success credit: **Cleaned by YoshiMamata#MUE**.

Tests: Go unit/integration tests cover local lockfile parsing, activity timestamps, CSV injection, demo safety, API authorization, protected contacts, typed confirmation, full backup, deletion, and list refresh. Browser UI was previewed with fictional/mock data. Live Windows/Riot account compatibility is not verified here.
